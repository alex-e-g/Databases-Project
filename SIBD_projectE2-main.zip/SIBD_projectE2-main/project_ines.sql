-- PROJECT PART 2 --

CREATE TABLE department(
    did INTEGER,
    name VARCHAR(80) NOT NULL,
    budget NUMERIC(12,4) NOT NULL,
    PRIMARY KEY(did),
    UNIQUE(name) -- optional
);


-- ENTITIES
-- country
create table country(
    iso_code integer,
    -- flag varchar
    name varchar(80) not null,
    primary key(iso_code),
    unique(name)
    -- unique(flag) maybe put this in a separate table to improve efficiency
);

create table location(
    longitude numeric(9,6),
    latitude numeric(8,6),
    name varchar(80) not null,
    primary key (longitude, latitude)
    -- Every location must exist in either tables 'marina', 'warf'
    -- or 'port'. (mandatory constraint)
    -- No location can be simultaneously in either of the tables
    -- 'marina', 'warf' or 'port'. (disjoint constraint)
);

create table marina(
    longitude numeric(9,6),
    latitude numeric(8,6),
    primary key (longitude, latitude),
    foreign key (longitude) references location(longitude),
    foreign key (latitude) references location(latitude)
);

create table warf(
    longitude numeric(9,6),
    latitude numeric(8,6),
    primary key (longitude, latitude),
    foreign key (longitude) references location(longitude),
    foreign key (latitude) references location(latitude)
);

create table port(
    longitude numeric(9,6),
    latitude numeric(8,6),
    primary key (longitude, latitude),
    foreign key (longitude) references location(longitude),
    foreign key (latitude) references location(latitude)
);

create table person(
    iso_code integer,
    id_card integer,
    name varchar(80) not null,
    primary key (iso_code, id_card),
    foreign key (iso_code) references country(iso_code)
    -- Every person must exist either in table 'owner' or table 'sailor'.
);

create table owner(
    iso_code integer,
    id_card integer,
    birthdate date not null,
    primary key (iso_code, id_card),
    foreign key (iso_code) references country(iso_code),
    foreign key (id_card) references person(id_card)
);

create table sailor(
    iso_code integer,
    id_card integer,
    primary key (iso_code, id_card),
    foreign key (iso_code) references country(iso_code),
    foreign key (id_card) references person(id_card)
);

create table schedule(
    start_date date,
    end_date date,
    primary key(start_date, end_date)
);

create table boat(
    iso_code integer,
    cni integer,
    length integer not null,
    year numeric(4,0) not null,
    name varchar(80) not null,
    primary key (iso_code, cni),
    foreign key (iso_code) references country(iso_code)
);

create table vhf_radio(
    iso_code integer,
    cni integer,
    mmsi integer not null,
    primary key (iso_code, cni),
    foreign key (iso_code) references country(iso_code),
    foreign key (cni) references boat(cni)
);

-- AGGREGATION
create table reservation(
    -- sailor
    iso_code_person integer,
    id_card integer,
    -- boat
    iso_code_boat integer,
    cni integer,
    -- schedule
    start_date date,
    end_date date,
    -- add primary keys from all entities in the association
    primary key (iso_code_person, id_card, iso_code_boat, cni, start_date, end_date),
    foreign key (iso_code_person) references country(iso_code),
    foreign key (iso_code_boat) references country(iso_code),
    foreign key (id_card) references person(id_card),
    foreign key (start_date) references schedule(start_date),
    foreign key (end_date) references schedule(end_date)
);

create table trip(
    iso_code_person integer,
    id_card integer,
    iso_code_boat integer,
    cni integer,
    start_date date,
    end_date date,
    date date,
    duration interval not null,
    primary key (iso_code_person, id_card, iso_code_boat, cni, start_date, end_date, date),
    foreign key (iso_code_person) references reservation(iso_code_person),
    foreign key (iso_code_boat) references reservation(iso_code_boat),
    foreign key (id_card) references reservation(id_card),
    foreign key (start_date) references reservation(start_date),
    foreign key (end_date) references reservation(end_date)
);

-- ASSOCIATIONS
-- country to location
create table authority(
    iso_code integer,
    longitude numeric(9,6),
    latitude numeric(8,6),
    primary key (iso_code, longitude, latitude),
    foreign key (iso_code) references country(iso_code),
    foreign key (longitude) references location(longitude),
    foreign key (latitude) references location(latitude)
);


-- trip to location
create table to_loc(
    -- trip
    iso_code_person integer,
    id_card integer,
    iso_code_boat integer,
    cni integer,
    start_date date,
    end_date date,
    date date,
    -- location
    longitude numeric(9,6) not null, -- not null because doesn't belong to PK
    latitude numeric(8,6) not null, -- not null because doesn't belong to PK
    -- primary key only from trip
    primary key (iso_code_person, id_card, iso_code_boat, cni, start_date, end_date, date),
    foreign key (iso_code_person) references trip(iso_code_person),
    foreign key (iso_code_boat) references trip(iso_code_boat),
    foreign key (id_card) references trip(id_card),
    foreign key (start_date) references trip(start_date),
    foreign key (end_date) references trip(end_date),
    foreign key (longitude) references location(longitude),
    foreign key (latitude) references location(latitude)
);

create table from_loc(
    -- trip
    iso_code_person integer,
    id_card integer,
    iso_code_boat integer,
    cni integer,
    start_date date,
    end_date date,
    date date,
    -- location
    longitude numeric(9,6) not null, -- not null because doesn't belong to PK
    latitude numeric(8,6) not null, -- not null because doesn't belong to PK
    -- primary key only from trip
    primary key (iso_code_person, id_card, iso_code_boat, cni, start_date, end_date, date),
    foreign key (iso_code_person) references trip(iso_code_person),
    foreign key (iso_code_boat) references trip(iso_code_boat),
    foreign key (id_card) references trip(id_card),
    foreign key (start_date) references trip(start_date),
    foreign key (end_date) references trip(end_date),
    foreign key (longitude) references location(longitude),
    foreign key (latitude) references location(latitude)
);