create table country
(
    iso_code integer,
    flag     varchar, -- shouldn't this be an image?
    name     varchar(80) not null,
    primary key (iso_code),
    unique (name),
    unique (flag)
);

create table boat(
    iso_code integer,
    cni integer,
    length integer not null,
    year numeric(4,0) not null,
    name varchar(80) not null,
    primary key (iso_code, cni),
    foreign key (iso_code) references country(iso_code)
);

create table boat_with_vhf(
    iso_code integer,
    cni integer,
    mmsi integer not null,
    primary key (iso_code, cni),
    foreign key (iso_code) references boat(iso_code),
    foreign key (cni) references boat(cni)
);

create table location(
    name varchar(80) not null ,
    latitude numeric(8,6),
    longitude numeric(9,6),
    iso_code integer not null,
    primary key(latitude,longitude),
    foreign key (iso_code) references country(iso_code)
    -- Every location must exist either in the table 'marina',
    -- in the table 'wharf' or in the table 'port'.
    -- No location can exist at the same time in the tables
    -- 'marina', 'wharf', or 'port'.
);

create table marina(
    latitude numeric(8,6),
    longitude numeric(9,6),
    primary key(latitude,longitude),
    foreign key(latitude) references location(latitude),
    foreign key (longitude) references location(longitude)
);

create table wharf(
    latitude numeric(8,6),
    longitude numeric(9,6),
    primary key(latitude,longitude),
    foreign key(latitude) references location(latitude),
    foreign key (longitude) references location(longitude)
);

create table port(
    latitude numeric(8,6),
    longitude numeric(9,6),
    primary key(latitude,longitude),
    foreign key(latitude) references location(latitude),
    foreign key (longitude) references location(longitude)
);

create table person(
    iso_code integer,
    id_card integer,
    name varchar(80),
    primary key (iso_code,id_card),
    foreign key (iso_code) references country(iso_code)
    -- Every person must exist either in the table 'owner'
    -- or in the table 'sailor'
);

create table owner(
    iso_code integer,
    id_card integer,
    birthdate date not null,
    primary key (iso_code, id_card),
    foreign key (iso_code) references country(iso_code),
    foreign key (id_card) references person(id_card)
);

create table sailor(
    iso_code integer,
    id_card integer,
    primary key (iso_code, id_card),
    foreign key (iso_code) references country(iso_code),
    foreign key (id_card) references person(id_card)
);

create table schedule(
    start_date date,
    end_date date,
    primary key(start_date, end_date)
);


-- Aggregation
create table reservation(
    --boat
    iso_code_boat integer,
    cni integer,
    --sailor
    iso_code_person integer,
    id_card integer,
    --schedule
    start_date date,
    end_date date,
    primary key (iso_code_boat,cni,iso_code_person,id_card,start_date,end_date),
    foreign key (iso_code_boat,cni) references boat(iso_code,cni),
    foreign key (iso_code_person,id_card) references sailor(iso_code, id_card),
    foreign key (start_date,end_date) references schedule(start_date, end_date)
);

create table trip(
    --boat
    iso_code_boat integer,
    cni integer,
    --sailor
    iso_code_person integer,
    id_card integer,
    --schedule
    start_date date,
    end_date date,
    --trip
    trip_date date,
    duration interval,
    --from
    from_latitude numeric(8,6),
    from_longitude numeric(9,6),
    --to
    to_latitude numeric(8,6),
    to_longitude numeric(9,6),
    primary key (iso_code_person, id_card, iso_code_boat, cni, start_date, end_date, trip_date),
    foreign key (iso_code_boat,cni,iso_code_person,id_card,start_date,end_date) references reservation(iso_code_boat,cni,iso_code_person,id_card,start_date,end_date)
    foreign key (from_latitude,from_longitude) references location(latitude,longitude),
    foreign key (to_latitude,to_longitude) references location(latitude,longitude)
);